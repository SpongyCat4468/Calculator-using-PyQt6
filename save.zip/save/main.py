from PyQt6.QtWidgets import QApplication, QDialog
from ui2 import Ui_Dialog
import sys
import math

class MainWindow(QDialog):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)

        self.x = 0 
        self.temp = 0
        self.mode = ""

        self.ui.pushButton_1.clicked.connect(lambda: self.input_num(1))
        self.ui.pushButton_2.clicked.connect(lambda: self.input_num(2))
        self.ui.pushButton_3.clicked.connect(lambda: self.input_num(3))
        self.ui.pushButton_4.clicked.connect(lambda: self.input_num(4))
        self.ui.pushButton_5.clicked.connect(lambda: self.input_num(5))
        self.ui.pushButton_6.clicked.connect(lambda: self.input_num(6))
        self.ui.pushButton_7.clicked.connect(lambda: self.input_num(7))
        self.ui.pushButton_8.clicked.connect(lambda: self.input_num(8))
        self.ui.pushButton_9.clicked.connect(lambda: self.input_num(9))
        self.ui.pushButton_10.clicked.connect(lambda: self.input_num(0))  
        self.ui.pushButton_11.clicked.connect(lambda: self.double_zero())
        self.ui.pushButton_reset.clicked.connect(lambda: self.reset())
        self.ui.pushButton_add.clicked.connect(lambda: self.add())
        self.ui.pushButton_minus.clicked.connect(lambda: self.minus())
        self.ui.pushButton_mul.clicked.connect(lambda: self.mul())
        self.ui.pushButton_div.clicked.connect(lambda: self.div())
        self.ui.pushButton_equal.clicked.connect(lambda: self.equal())
        self.ui.pushButton_root.clicked.connect(lambda: self.root())
        self.ui.pushButton_sqaure.clicked.connect(lambda: self.square())


    def input_num(self, num):
        self.x = self.x * 10 + num
        self.refresh()

    def double_zero(self):
        self.x = self.x * 100
        self.refresh()

    def refresh(self):
        self.ui.plainTextEdit.setPlainText(str(self.x))  

    def reset(self):
        self.x = 0
        self.refresh()

    def add(self):
        self.temp = self.x
        self.x = 0
        self.mode = "add"
        self.refresh()

    def minus(self):
        self.temp = self.x
        self.x = 0
        self.mode = "minus"
        self.refresh()

    def mul(self):
        self.temp = self.x
        self.x = 0
        self.mode = "mul"
        self.refresh()

    def div(self):
        self.temp = self.x
        self.x = 0
        self.mode = "div"
        self.refresh()

    def root(self):
        self.x = math.sqrt(self.x)
        self.refresh()

    def square(self):
        self.x = self.x * self.x
        self.refresh()
    
    def equal(self):
        if self.mode == "add":
            self.x = self.temp + self.x
        elif self.mode == "minus":
            self.x = self.temp - self.x
        elif self.mode == "mul":
            self.x = self.temp * self.x
        elif self.mode == "div":
            self.x = self.temp / self.x
        self.refresh()
        


if __name__ == "__main__":
    
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())